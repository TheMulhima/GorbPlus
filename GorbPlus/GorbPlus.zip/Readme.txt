#Gorb Plus
A mod that adds an additional attack when fighting gorb: a nail barrage.
The time between nails can be changed in modmenu.